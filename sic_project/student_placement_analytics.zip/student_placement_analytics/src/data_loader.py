import pandas as pd
import mysql.connector
from datetime import datetime
from db_config import get_connection
def load_all_data():
    conn = get_connection()
    student1_df = pd.read_sql("SELECT * FROM student1", conn)
    student2_df = pd.read_sql("SELECT * FROM student", conn)
    company_df = pd.read_sql("SELECT * FROM company", conn)
    performance_df = pd.read_sql("SELECT * FROM performance", conn)
    hiring_df = pd.read_sql("SELECT * FROM hiring", conn)
    query = """
    SELECT s.usn, s.name, s.dept, s.batch, s.cgpa,
        p.status, c.company
    FROM student s
    LEFT JOIN performance p ON s.usn = p.usn
    LEFT JOIN company c ON p.cid = c.cid;
    """
    combined_df = pd.read_sql(query, conn)
    conn.close()
    return student1_df,student2_df, company_df, performance_df, hiring_df, combined_df
