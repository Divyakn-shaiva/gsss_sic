#THE ENTIRE student_placement_analytics FOLDER SHOULD BE PLACED INSIDE XAMPP --> HTDOCS

import streamlit as st
import pandas as pd
import plotly.express as px
from src.data_loader import load_all_data
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import streamlit as st
STATUS_MAP = {                      
    0: "Not Eligible",
    1: "Unable to Clear 1st Round",            # Map Status Code  
    2: "Unable to Clear GD",
    3: "Unable to Clear Technicals",
    4: "Unable to Clear HR",
    9: "Shortlisted",
    10: "Placed"
}
def map_status(status_code):
    return STATUS_MAP.get(status_code, "Unknown")
def apply_filters(df, batch_filter, dept_filter, company_filter = None): #Functions to apply Filters
    filtered = df.copy()
    # Handling Batch Filter
    all_batches = sorted(filtered['batch'].dropna().unique())
    if batch_filter == "Last 3 Years" and len(all_batches) >= 3:
        recent_batches = all_batches[-3:]
        filtered = filtered[filtered['batch'].isin(recent_batches)]
    elif batch_filter not in ["Last 3 Years", "All"]:
        filtered = filtered[filtered['batch'] == batch_filter]
    # Handling Department Filter
    if dept_filter != "All":
        filtered = filtered[filtered['dept'] == dept_filter]
    #  Handling Company Filter
    if company_filter and company_filter != "All" and 'company' in filtered.columns:
        filtered = filtered[filtered['company'] == company_filter]
    return filtered
# Compute Total students,total paced
def compute_kpis(student_filtered_df, filtered_df):
    total_students = student_filtered_df['id'].nunique()
    total_placed = filtered_df[filtered_df['status'].isin([9, 10])]['id'].nunique()
    return total_students, total_placed
def main():    # Main Dashboard
    st.set_page_config(page_title="Student Placement Analysis", layout = "wide")
    st.title("🎓 Student Placement Analysis Dashboard")
    @st.cache_data          # Load Data
    def get_all_data():
        return load_all_data()
    student1_df, student2_df, company_df, performance_df, hiring_df, combined_df = get_all_data()
    # Clean columns
    student1_df['dept'] = student1_df['dept'].astype(str).str.strip()
    student1_df['batch'] = student1_df['batch'].astype(str).str.strip()
    company_df['company'] = company_df['company'].astype(str).str.strip()
    # Merge data
    merged_df = (
        performance_df
        .merge(student2_df, on = "id", how = "left")
        .merge(company_df, on = "cid", how = "left")
    )
    merged_df['status_text'] = merged_df['status'].apply(map_status)
    if st.sidebar.button("Clear Cache"):
        st.cache_data.clear()
    # Sidebar Filters
    st.sidebar.header("🔎 Filters")
    all_batches = sorted(student1_df['batch'].dropna().unique())
    selected_batch = st.sidebar.selectbox("Select Batch", ["All", "Last 3 Years"] + all_batches)
    all_departments = sorted(student1_df['dept'].dropna().unique())
    selected_dept = st.sidebar.selectbox("Select Department", ["All"] + all_departments)
    all_companies = sorted(company_df['company'].dropna().unique())
    selected_company = st.sidebar.selectbox("Select Company", ["All"] + all_companies)
    st.sidebar.subheader("CGPA Analysis")
    show_cgpa_button = st.sidebar.button("Show CGPA Placement Analysis")
    # Applying  filters
    student_filtered = apply_filters(student1_df, selected_batch, selected_dept)
    filtered_df = apply_filters(merged_df, selected_batch, selected_dept, selected_company)
    total_students, total_placed = compute_kpis(student_filtered, filtered_df)
    st.subheader("📊 Key Performance Indicators")
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Students", total_students)
    col2.metric("Placed (Shortlisted + Placed)", total_placed)
    # Placement Status Distribution
    st.subheader(" Placement Status Distribution")
    if not filtered_df.empty:
        status_counts = (filtered_df['status_text'].value_counts(normalize=True) * 100).reset_index()
        status_counts.columns = ['Status', 'Percentage']
        fig_status = px.bar(
            status_counts,
            x = 'Status',
            y = 'Percentage',
            color = 'Status',
            title = 'Placement Status (%)',
            text = status_counts['Percentage'].map("{:.1f}%".format)
        )
        fig_status.update_layout(yaxis_title="Percentage of Students")
        st.plotly_chart(fig_status, use_container_width = True)
    else:
        st.info("No data available for the selected filters.")
    # Placement by Batch
    if 'batch' in filtered_df.columns:
        st.subheader("Placement by Batch")
        batch_stats = filtered_df.groupby(['batch', 'status_text']).size().reset_index(name = 'count')
        if not batch_stats.empty:
            fig_batch = px.bar(
                batch_stats,
                x = 'batch',
                y = 'count',
                color = 'status_text',
                barmode = 'stack',
                title = 'Batch-wise Placement Status'
            )
            st.plotly_chart(fig_batch, use_container_width=True)
    # Placement by Branch
    if 'branch' in filtered_df.columns:
        st.subheader("Placement by Branch")
        branch_stats = filtered_df.groupby(['branch', 'status_text']).size().unstack(fill_value = 0)
        st.bar_chart(branch_stats)
    # Top Recruiters
    @st.cache_data
    def get_top_companies(df):
        placed = df[df['status'].isin([9, 10])]
        return placed['company'].value_counts().head(10) if not placed.empty else pd.Series()

    st.subheader("🏢 Top Recruiters (Shortlisted + Placed)")
    top_companies = get_top_companies(filtered_df)
    if not top_companies.empty:
        st.bar_chart(top_companies)
    else:
        st.info("⚠️ No shortlisted/placed students found.")
    # CGPA Placement Analysis (Donut)
    if show_cgpa_button:
        required_cols = {'CGPA', 'company', 'batch', 'status'}
        if required_cols.issubset(merged_df.columns):
            cgpa_data = merged_df.copy()
            cgpa_data['CGPA'] = pd.to_numeric(cgpa_data['CGPA'], errors = 'coerce')
            cgpa_data['batch'] = pd.to_numeric(cgpa_data['batch'], errors = 'coerce')
            cgpa_data = cgpa_data.dropna(subset = ['CGPA', 'batch'])
            cgpa_data['batch'] = cgpa_data['batch'].astype(int)
            # Filter by batch
            if selected_batch == "Last 3 Years":
                max_batch = cgpa_data['batch'].max()
                batches_to_show = list(range(max_batch - 2, max_batch + 1))
                cgpa_data = cgpa_data[cgpa_data['batch'].isin(batches_to_show)]
            elif selected_batch != "All":
                cgpa_data = cgpa_data[cgpa_data['batch'] == int(selected_batch)]
                batches_to_show = [selected_batch]
            else:
                batches_to_show = sorted(cgpa_data['batch'].unique())
            # Filter by department
            if selected_dept != "All":
                cgpa_data = cgpa_data[cgpa_data['dept'] == selected_dept]
            # Filter by company
            if selected_company != "All":
                cgpa_data = cgpa_data[cgpa_data['company'] == selected_company]

            if not cgpa_data.empty:
                bins = [0, 7, 8, 9, 10]
                labels = ["<7", "7-8", "8-9", "9-10"]
                cgpa_data['CGPA_Range'] = pd.cut(cgpa_data['CGPA'], bins = bins, labels = labels, right = False)
                placed_df = cgpa_data[cgpa_data['status'].isin([9, 10])]
                st.markdown(f"### 🎓 CGPA Placement Analysis ({', '.join(map(str, batches_to_show))})")
                # Count all students
                all_counts = cgpa_data['CGPA_Range'].value_counts().sort_index().reset_index()
                all_counts.columns = ['CGPA_Range', 'Count']
                # Count placed students
                placed_counts = placed_df['CGPA_Range'].value_counts().sort_index().reset_index()
                placed_counts.columns = ['CGPA_Range', 'Count']
                # Create subplots with donut charts
                fig = make_subplots(
                    rows = 1, cols = 2,
                    specs = [[{'type': 'domain'}, {'type': 'domain'}]],
                    subplot_titles = ['All Students CGPA Distribution', 'Placed Students CGPA Distribution']
                )
                fig.add_trace(
                    go.Pie(
                        labels = all_counts['CGPA_Range'],
                        values = all_counts['Count'],
                        hole = 0.4,
                        textinfo = 'label+value',
                        hovertemplate = 'CGPA Range: %{label}<br>Count: %{value}<extra></extra>'
                    ), row = 1, col = 1
                )
                fig.add_trace(
                    go.Pie(
                        labels = placed_counts['CGPA_Range'],
                        values = placed_counts['Count'],
                        hole = 0.4,
                        textinfo = 'label+value',
                        hovertemplate = 'CGPA Range: %{label}<br>Count: %{value}<extra></extra>'
                    ), row = 1, col = 2
                )
                fig.update_layout(title_text = "CGPA Placement Analysis", showlegend = True)
                st.plotly_chart(fig, use_container_width = True)
            else:
                st.info(f" No valid CGPA data available for {selected_batch} and selected filters.")
        else:
            st.warning(" Required columns (CGPA, company, batch, status) not found.")
    # Hiring Records Table (sticky first 4 columns, horizontal scroll)
    st.subheader("Hiring Records")
    if not filtered_df.empty:
        pivot_df = filtered_df.pivot_table(
            index = ['id', 'name', 'dept', 'batch'],
            columns = 'company',
            values = 'status_text',
            aggfunc = 'first'
        ).reset_index()
        # Clean up for display
        pivot_df = pivot_df.fillna('Null')
        # Remove the top-left "company" header row that pandas adds for column MultiIndex
        pivot_df.columns.name = None
        table_html = pivot_df.to_html(index = False, classes = 'sticky-table', escape = False)
        # Fixed widths + correct cumulative left offsets for sticky columns
        custom_css = """
        <style>
        .sticky-wrapper {
            overflow: auto;            /* both axes if needed */
            max-height: 500px;         /* same as your earlier height */
            width: 100%;
            border: 1px solid #e6e6e6;
            border-radius: 8px;
        }
        .sticky-table {
            border-collapse: separate;
            border-spacing: 0;
            width: max-content;        /* allow horizontal expansion */
            min-width: 100%;
        }
        .sticky-table th, .sticky-table td {
            border: 1px solid #ddd;
            padding: 8px 10px;
            text-align: left;
            white-space: nowrap;
            background: #fff;          /* important for sticky overlap */
        }
        /* sticky header row */
        .sticky-table thead th {
            position: sticky;
            top: 0;
            z-index: 3;
            background: #f7f7f7;
        }

        /* Fixed widths for the first 4 columns (adjust if you like) */
        .sticky-table th:nth-child(1), .sticky-table td:nth-child(1) { min-width: 80px;  max-width: 80px;  }
        .sticky-table th:nth-child(2), .sticky-table td:nth-child(2) { min-width: 220px; max-width: 220px; }
        .sticky-table th:nth-child(3), .sticky-table td:nth-child(3) { min-width: 140px; max-width: 140px; }
        .sticky-table th:nth-child(4), .sticky-table td:nth-child(4) { min-width: 90px;  max-width: 90px;  }

        /* Sticky positions with correct cumulative offsets:
            col1 left = 0
            col2 left = 80px
            col3 left = 80+220 = 300px
            col4 left = 300+140 = 440px
        */
        .sticky-table th:nth-child(1), .sticky-table td:nth-child(1) { position: sticky; left: 0px;   z-index: 4; }
        .sticky-table th:nth-child(2), .sticky-table td:nth-child(2) { position: sticky; left: 80px;  z-index: 4; }
        .sticky-table th:nth-child(3), .sticky-table td:nth-child(3) { position: sticky; left: 300px; z-index: 4; }
        .sticky-table th:nth-child(4), .sticky-table td:nth-child(4) { position: sticky; left: 440px; z-index: 4; }

        /* Optional: subtle row hover */
        .sticky-table tbody tr:hover td { background: #fafafa; }
        </style>
        """

        st.markdown(custom_css, unsafe_allow_html = True)
        st.markdown(f'<div class = "sticky-wrapper">{table_html}</div>', unsafe_allow_html = True)
        # CSV Download Button
        st.download_button(
            label = " Download CSV",
            data = pivot_df.to_csv(index=False).encode('utf-8'),
            file_name = "hiring_records.csv",
            mime = "text/csv"
        )
    else:
        st.info("No hiring records to display for selected filters.")
if __name__ == "__main__":
    main()
