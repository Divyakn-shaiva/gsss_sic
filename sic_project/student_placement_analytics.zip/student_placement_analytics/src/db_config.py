import mysql.connector

def get_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",          # Your MySQL password
            database="statistics",  # Your DB name
            port=3307             # Change to actual port from XAMPP
        )
        return conn
    except mysql.connector.Error as err:
        print(f"MySQL connection error: {err}")
        return None
